# Test kontrol listesi

- [ ] İki fiziksel telefonda oda oluşturma ve katılma
- [ ] Beşinci kullanıcının reddedilmesi
- [ ] Mikrofon izin reddi
- [ ] Bildirim izin reddi
- [ ] Ana ekrana dönünce sesin sürmesi
- [ ] Ekran kilidinde sesin sürmesi
- [ ] Wi-Fi → mobil veri geçişi
- [ ] Bluetooth kulaklık bağlama/çıkarma
- [ ] Gelen telefon aramasında ses davranışı
- [ ] PTT basma/bırakma ve ACTION_CANCEL
- [ ] Oda boşalınca 15 saniye sonra kapanma
- [ ] %5 paket kaybı ve 200 ms RTT
- [ ] Bir saatlik veri, pil ve sıcaklık ölçümü
