# OyunSesi MVP

Android oyuncuları için 4 kişilik, WebRTC/Opus tabanlı sesli oda prototipi.

## APK kullanımı

APK kurulduktan sonra uygulamaya çalışan backend adresi girilir. Backend, LiveKit erişim token'ı üretir; API anahtarı veya secret hiçbir zaman APK'ya konmaz.

## Yerel derleme

Android Studio ile `android/` klasörünü açın veya:

```bash
cd android
./gradlew assembleDebug
```

## Sunucu

1. `backend/.env.example` dosyasını `.env` olarak kopyalayın.
2. Domain ve LiveKit anahtarlarını değiştirin.
3. `infra/livekit.yaml` içindeki domain ve anahtarları değiştirin.
4. TLS reverse proxy ve gerekli UDP/TCP portlarını açın.
5. Docker Compose ile çalıştırın.

Geliştirme yapılandırmasını internete olduğu gibi açmayın. Rate limit, TLS, log saklama politikası ve abuse/report mekanizması üretimden önce tamamlanmalıdır.

## Gizlilik

- Recording/Egress özelliği kullanılmaz.
- Ses dosyası depolanmaz.
- Muting, ses verisinin sunucuya gönderimini durdurur.
- Odadan ayrılınca mikrofon bağlantısı kapatılır.
