export function generateRoomCode(random: () => number = Math.random): string {
  return Math.floor(100000 + random() * 900000).toString();
}

export function normalizeCode(value: string): string {
  if (!/^\d{6}$/.test(value)) throw new Error("Oda kodu 6 haneli olmalı");
  return value;
}
