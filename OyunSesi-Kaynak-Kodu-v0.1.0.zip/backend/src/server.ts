import Fastify from "fastify";
import cors from "@fastify/cors";
import rateLimit from "@fastify/rate-limit";
import { AccessToken, RoomServiceClient } from "livekit-server-sdk";
import { z } from "zod";
import { generateRoomCode, normalizeCode } from "./room-code.js";

const env = z.object({
  PORT: z.coerce.number().default(3000),
  PUBLIC_LIVEKIT_URL: z.string().url(),
  LIVEKIT_HTTP_URL: z.string().url(),
  LIVEKIT_API_KEY: z.string().min(3),
  LIVEKIT_API_SECRET: z.string().min(8),
}).parse(process.env);

const joinBody = z.object({
  displayName: z.string().trim().min(2).max(20),
  lowData: z.boolean().default(true),
});

const app = Fastify({
  logger: { redact: ["req.headers.authorization", "participantToken"] },
  bodyLimit: 16 * 1024,
});
await app.register(cors, { origin: false });
await app.register(rateLimit, { max: 30, timeWindow: "1 minute" });

const rooms = new RoomServiceClient(
  env.LIVEKIT_HTTP_URL,
  env.LIVEKIT_API_KEY,
  env.LIVEKIT_API_SECRET,
);

async function roomExists(code: string): Promise<boolean> {
  const result = await rooms.listRooms([code]);
  return result.length > 0;
}

async function uniqueRoomCode(): Promise<string> {
  for (let attempt = 0; attempt < 20; attempt++) {
    const code = generateRoomCode();
    if (!(await roomExists(code))) return code;
  }
  throw new Error("Uygun oda kodu üretilemedi");
}

async function credentials(code: string, displayName: string, lowData: boolean) {
  const participantId = crypto.randomUUID();
  const token = new AccessToken(env.LIVEKIT_API_KEY, env.LIVEKIT_API_SECRET, {
    identity: participantId,
    name: displayName,
    ttl: "5m",
    metadata: JSON.stringify({ lowData }),
  });
  token.addGrant({
    room: code,
    roomJoin: true,
    canPublish: true,
    canSubscribe: true,
    canPublishData: false,
  });
  return {
    roomCode: code,
    participantId,
    participantToken: await token.toJwt(),
    serverUrl: env.PUBLIC_LIVEKIT_URL,
  };
}

app.get("/v1/health", async () => ({ ok: true }));

app.post("/v1/rooms", { config: { rateLimit: { max: 8, timeWindow: "1 minute" } } }, async (request, reply) => {
  const parsed = joinBody.safeParse(request.body);
  if (!parsed.success) return reply.code(400).send({ message: "Kullanıcı adı veya ayarlar geçersiz." });
  const code = await uniqueRoomCode();
  await rooms.createRoom({
    name: code,
    maxParticipants: 4,
    emptyTimeout: 120,
    departureTimeout: 15,
  });
  return reply.code(201).send(await credentials(code, parsed.data.displayName, parsed.data.lowData));
});

app.post("/v1/rooms/:code/join", { config: { rateLimit: { max: 10, timeWindow: "1 minute" } } }, async (request, reply) => {
  let code: string;
  try {
    code = normalizeCode((request.params as { code: string }).code);
  } catch {
    return reply.code(400).send({ message: "Oda kodu 6 haneli olmalı." });
  }
  const parsed = joinBody.safeParse(request.body);
  if (!parsed.success) return reply.code(400).send({ message: "Kullanıcı adı veya ayarlar geçersiz." });
  const [room] = await rooms.listRooms([code]);
  if (!room) return reply.code(404).send({ message: "Oda bulunamadı veya kapanmış." });
  if (room.numParticipants >= 4) return reply.code(409).send({ message: "Oda dolu." });
  return reply.send(await credentials(code, parsed.data.displayName, parsed.data.lowData));
});

app.setErrorHandler((error, _request, reply) => {
  app.log.error(error);
  reply.code(500).send({ message: "Beklenmeyen sunucu hatası." });
});

await app.listen({ port: env.PORT, host: "0.0.0.0" });
