# MVP: shrinking is disabled. Add LiveKit-specific keep rules before enabling it.
