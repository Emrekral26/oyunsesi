package com.oyunsesi.app.voice

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.oyunsesi.app.MainActivity
import com.oyunsesi.app.R
import io.livekit.android.LiveKit
import io.livekit.android.events.RoomEvent
import io.livekit.android.events.collect
import io.livekit.android.room.Room
import io.livekit.android.room.participant.AudioTrackPublishDefaults
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class VoiceSessionService : Service() {
    companion object {
        const val ACTION_START = "com.oyunsesi.START"
        const val ACTION_TOGGLE_MUTE = "com.oyunsesi.TOGGLE_MUTE"
        const val ACTION_SET_MUTED = "com.oyunsesi.SET_MUTED"
        const val ACTION_LEAVE = "com.oyunsesi.LEAVE"
        const val ACTION_STATE = "com.oyunsesi.STATE"
        const val EXTRA_TOKEN = "token"
        const val EXTRA_URL = "url"
        const val EXTRA_CODE = "code"
        const val EXTRA_MUTED = "muted"
        const val EXTRA_LOW_DATA = "low_data"
        const val EXTRA_START_MUTED = "start_muted"
        private const val CHANNEL_ID = "voice_session"
        private const val NOTIFICATION_ID = 1201
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var room: Room? = null
    private var eventJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val code = intent.getStringExtra(EXTRA_CODE).orEmpty()
                startAsForeground(code)
                connect(
                    intent.getStringExtra(EXTRA_URL).orEmpty(),
                    intent.getStringExtra(EXTRA_TOKEN).orEmpty(),
                    code,
                    intent.getBooleanExtra(EXTRA_LOW_DATA, true),
                    intent.getBooleanExtra(EXTRA_START_MUTED, false)
                )
            }
            ACTION_TOGGLE_MUTE -> setMuted(!VoiceSessionStore.state.muted)
            ACTION_SET_MUTED -> setMuted(intent.getBooleanExtra(EXTRA_MUTED, true))
            ACTION_LEAVE -> leave()
        }
        return START_NOT_STICKY
    }

    private fun connect(url: String, token: String, code: String, lowData: Boolean, startMuted: Boolean) {
        if (room != null) return
        update(VoiceSessionState(roomCode = code, status = "Bağlanıyor…"))
        scope.launch {
            try {
                val newRoom = LiveKit.create(applicationContext)
                newRoom.audioTrackPublishDefaults = AudioTrackPublishDefaults(
                    audioBitrate = if (lowData) 12_000 else 24_000,
                    dtx = true,
                    red = !lowData,
                    preconnect = false
                )
                room = newRoom
                eventJob = scope.launch {
                    newRoom.events.collect { event: RoomEvent ->
                        when (event) {
                            is RoomEvent.ParticipantConnected,
                            is RoomEvent.ParticipantDisconnected -> refreshParticipantCount()
                            is RoomEvent.Disconnected -> update(
                                VoiceSessionStore.state.copy(
                                    connected = false,
                                    status = "Bağlantı kesildi",
                                    error = event.error?.message
                                )
                            )
                            else -> Unit
                        }
                    }
                }
                newRoom.connect(url, token)
                newRoom.localParticipant.setMicrophoneEnabled(!startMuted)
                update(
                    VoiceSessionStore.state.copy(
                        connected = true,
                        muted = startMuted,
                        status = if (startMuted) "Push-to-talk hazır" else "Sesli sohbet aktif",
                        participantCount = 1 + newRoom.remoteParticipants.size,
                        error = null
                    )
                )
            } catch (error: Throwable) {
                update(
                    VoiceSessionStore.state.copy(
                        connected = false,
                        status = "Bağlanamadı",
                        error = error.message ?: "Bilinmeyen bağlantı hatası"
                    )
                )
            }
        }
    }

    private fun refreshParticipantCount() {
        val activeRoom = room ?: return
        update(VoiceSessionStore.state.copy(participantCount = 1 + activeRoom.remoteParticipants.size))
    }

    private fun setMuted(muted: Boolean) {
        val activeRoom = room ?: return
        scope.launch {
            runCatching { activeRoom.localParticipant.setMicrophoneEnabled(!muted) }
                .onSuccess {
                    update(
                        VoiceSessionStore.state.copy(
                            muted = muted,
                            status = if (muted) "Mikrofon kapalı" else "Sesli sohbet aktif"
                        )
                    )
                }
                .onFailure { update(VoiceSessionStore.state.copy(error = it.message)) }
        }
    }

    private fun leave() {
        scope.launch {
            runCatching { room?.disconnect() }
            room = null
            eventJob?.cancel()
            update(VoiceSessionState())
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun update(state: VoiceSessionState) {
        VoiceSessionStore.state = state
        sendBroadcast(Intent(ACTION_STATE).setPackage(packageName))
        if (state.roomCode.isNotBlank()) {
            getSystemService(NotificationManager::class.java).notify(
                NOTIFICATION_ID,
                buildNotification(state)
            )
        }
    }

    private fun startAsForeground(code: String) {
        val initial = VoiceSessionState(roomCode = code, status = "Bağlanıyor…")
        VoiceSessionStore.state = initial
        ServiceCompat.startForeground(
            this,
            NOTIFICATION_ID,
            buildNotification(initial),
            if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
        )
    }

    private fun buildNotification(state: VoiceSessionState): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val muteIntent = PendingIntent.getService(
            this, 1, Intent(this, VoiceSessionService::class.java).setAction(ACTION_TOGGLE_MUTE),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val leaveIntent = PendingIntent.getService(
            this, 2, Intent(this, VoiceSessionService::class.java).setAction(ACTION_LEAVE),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_app)
            .setContentTitle("OyunSesi • Oda ${state.roomCode}")
            .setContentText(state.status)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .addAction(0, if (state.muted) "Mikrofonu aç" else "Mikrofonu kapat", muteIntent)
            .addAction(0, "Ayrıl", leaveIntent)
            .build()
    }

    private fun createChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Aktif sesli sohbet",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Arka planda devam eden sesli sohbeti gösterir."
            setSound(null, null)
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    override fun onDestroy() {
        runCatching { room?.disconnect() }
        room = null
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
