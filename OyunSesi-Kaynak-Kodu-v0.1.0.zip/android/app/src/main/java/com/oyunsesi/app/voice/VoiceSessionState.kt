package com.oyunsesi.app.voice

data class VoiceSessionState(
    val roomCode: String = "",
    val status: String = "Bağlı değil",
    val participantCount: Int = 0,
    val connected: Boolean = false,
    val muted: Boolean = false,
    val error: String? = null
)

object VoiceSessionStore {
    @Volatile var state = VoiceSessionState()
}
