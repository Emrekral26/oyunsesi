package com.oyunsesi.app

import android.Manifest
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.oyunsesi.app.api.ApiClient
import com.oyunsesi.app.api.JoinCredentials
import com.oyunsesi.app.voice.VoiceSessionService
import com.oyunsesi.app.voice.VoiceSessionStore
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("oyunsesi", MODE_PRIVATE) }
    private var pendingAction: (() -> Unit)? = null
    private var content: LinearLayout? = null

    private val stateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) = render()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7, 17, 31)
        window.navigationBarColor = Color.rgb(7, 17, 31)
        ContextCompat.registerReceiver(
            this,
            stateReceiver,
            IntentFilter(VoiceSessionService.ACTION_STATE),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        render()
    }

    override fun onDestroy() {
        unregisterReceiver(stateReceiver)
        super.onDestroy()
    }

    private fun render() {
        runOnUiThread {
            val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(7, 17, 31)) }
            content = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(22), dp(24), dp(22), dp(30))
            }
            scroll.addView(content)
            setContentView(scroll)
            if (VoiceSessionStore.state.roomCode.isBlank()) renderLobby() else renderRoom()
        }
    }

    private fun renderLobby() {
        val root = content ?: return
        root.addView(title("OYUNSESI", 13, Color.rgb(49, 215, 232)).apply { letterSpacing = .22f })
        root.addView(title("Takımınla konuş.\nOyunun akışını bozma.", 30, Color.WHITE).apply {
            setPadding(0, dp(10), 0, dp(8))
        })
        root.addView(body("4 kişiye kadar, düşük gecikmeli ve arka planda çalışan sesli oda."))

        val username = edit("Kullanıcı adı", prefs.getString("username", "").orEmpty())
        val server = edit("Backend adresi (https://…)", prefs.getString("server", "").orEmpty()).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        }
        val lowData = Switch(this).apply {
            text = "Düşük internet modu"
            setTextColor(Color.WHITE)
            textSize = 16f
            isChecked = prefs.getBoolean("lowData", true)
            setPadding(0, dp(12), 0, dp(12))
        }
        root.addView(card(username, server, lowData))

        root.addView(primaryButton("ODA OLUŞTUR") {
            saveSettings(username, server, lowData)
            withMicPermission { requestRoom(create = true, code = null) }
        })
        root.addView(secondaryButton("KODLA KATIL") {
            saveSettings(username, server, lowData)
            showJoinDialog()
        })

        root.addView(body("Gizlilik", bold = true).apply { setPadding(0, dp(26), 0, dp(4)) })
        root.addView(body("Mikrofon yalnızca canlı oda sırasında kullanılır. Ses kaydedilmez veya depolanmaz. Odaya katılınca uygulama arka plandayken de mikrofon etkin kalabilir."))
    }

    private fun renderRoom() {
        val root = content ?: return
        val state = VoiceSessionStore.state
        root.addView(title("ODA KODU", 13, Color.rgb(147, 164, 184)))
        root.addView(title(state.roomCode, 42, Color.WHITE).apply { letterSpacing = .14f })
        root.addView(body("${state.participantCount.coerceAtLeast(1)}/4 oyuncu • ${state.status}").apply {
            setTextColor(if (state.error == null) Color.rgb(49, 215, 232) else Color.rgb(255, 93, 108))
            setPadding(0, dp(6), 0, dp(26))
        })

        if (state.error != null) root.addView(body(state.error).apply { setTextColor(Color.rgb(255, 93, 108)) })

        val pttEnabled = prefs.getBoolean("ptt", false)
        val pttSwitch = Switch(this).apply {
            text = "Push-to-talk modu"
            setTextColor(Color.WHITE)
            textSize = 16f
            isChecked = pttEnabled
            setPadding(0, dp(4), 0, dp(16))
            setOnCheckedChangeListener { _, enabled ->
                prefs.edit().putBoolean("ptt", enabled).apply()
                setServiceMuted(enabled)
                render()
            }
        }
        root.addView(pttSwitch)

        if (pttEnabled) {
            val ptt = primaryButton("BASILI TUT VE KONUŞ", null).apply {
                setBackgroundColor(Color.rgb(23, 76, 90))
                setOnTouchListener { _, event ->
                    when (event.actionMasked) {
                        MotionEvent.ACTION_DOWN -> setServiceMuted(false)
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> setServiceMuted(true)
                    }
                    true
                }
            }
            root.addView(ptt)
            root.addView(body("Butona basarken mikrofon açılır, bırakınca kapanır.").apply {
                setPadding(0, dp(4), 0, dp(20))
            })
        } else {
            root.addView(primaryButton(if (state.muted) "MİKROFONU AÇ" else "MİKROFONU KAPAT") {
                sendServiceAction(VoiceSessionService.ACTION_TOGGLE_MUTE)
            })
        }
        root.addView(dangerButton("ODADAN AYRIL") {
            sendServiceAction(VoiceSessionService.ACTION_LEAVE)
        })
    }

    private fun showJoinDialog() {
        val input = EditText(this).apply {
            hint = "6 haneli kod"
            inputType = InputType.TYPE_CLASS_NUMBER
            setPadding(dp(18), dp(14), dp(18), dp(14))
        }
        AlertDialog.Builder(this)
            .setTitle("Odaya katıl")
            .setView(input)
            .setNegativeButton("İptal", null)
            .setPositiveButton("Katıl") { _, _ ->
                val code = input.text.toString().trim()
                if (code.length != 6) toast("Oda kodu 6 haneli olmalı.")
                else withMicPermission { requestRoom(create = false, code = code) }
            }.show()
    }

    private fun requestRoom(create: Boolean, code: String?) {
        val username = prefs.getString("username", "").orEmpty().trim()
        val server = prefs.getString("server", "").orEmpty().trim()
        if (username.length !in 2..20) return toast("Kullanıcı adı 2–20 karakter olmalı.")
        if (!server.startsWith("https://")) return toast("Geçerli HTTPS backend adresi gir.")
        toast("Oda hazırlanıyor…")
        thread {
            runCatching {
                val client = ApiClient(server)
                if (create) client.createRoom(username, prefs.getBoolean("lowData", true))
                else client.joinRoom(code!!, username, prefs.getBoolean("lowData", true))
            }.onSuccess { startVoiceService(it) }
                .onFailure { runOnUiThread { toast(it.message ?: "Bağlantı kurulamadı.") } }
        }
    }

    private fun startVoiceService(credentials: JoinCredentials) {
        val intent = Intent(this, VoiceSessionService::class.java).apply {
            action = VoiceSessionService.ACTION_START
            putExtra(VoiceSessionService.EXTRA_CODE, credentials.roomCode)
            putExtra(VoiceSessionService.EXTRA_TOKEN, credentials.participantToken)
            putExtra(VoiceSessionService.EXTRA_URL, credentials.serverUrl)
            putExtra(VoiceSessionService.EXTRA_LOW_DATA, prefs.getBoolean("lowData", true))
            putExtra(VoiceSessionService.EXTRA_START_MUTED, prefs.getBoolean("ptt", false))
        }
        ContextCompat.startForegroundService(this, intent)
        runOnUiThread { render() }
    }

    private fun withMicPermission(action: () -> Unit) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            requestNotificationIfNeeded()
            action()
            return
        }
        pendingAction = action
        AlertDialog.Builder(this)
            .setTitle("Mikrofon kullanımı")
            .setMessage("OyunSesi, yalnızca katıldığın canlı sesli odada konuşmanı diğer oyunculara iletmek için mikrofonu kullanır. Ses kaydedilmez. Sohbet, uygulama arka plandayken de devam edebilir.")
            .setNegativeButton("Şimdi değil", null)
            .setPositiveButton("Devam et") { _, _ -> requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 41) }
            .show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            requestNotificationIfNeeded()
            pendingAction?.invoke()
        } else if (requestCode == 41) toast("Sesli sohbet için mikrofon izni gerekiyor.")
        pendingAction = null
    }

    private fun requestNotificationIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 42)
    }

    private fun saveSettings(username: EditText, server: EditText, lowData: Switch) {
        prefs.edit()
            .putString("username", username.text.toString().trim())
            .putString("server", server.text.toString().trim())
            .putBoolean("lowData", lowData.isChecked)
            .apply()
    }

    private fun sendServiceAction(action: String) =
        startService(Intent(this, VoiceSessionService::class.java).setAction(action))

    private fun setServiceMuted(muted: Boolean) = startService(
        Intent(this, VoiceSessionService::class.java)
            .setAction(VoiceSessionService.ACTION_SET_MUTED)
            .putExtra(VoiceSessionService.EXTRA_MUTED, muted)
    )

    private fun title(text: String, size: Int, color: Int) = TextView(this).apply {
        this.text = text
        textSize = size.toFloat()
        setTextColor(color)
        setTypeface(typeface, Typeface.BOLD)
    }

    private fun body(text: String, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        textSize = 15f
        setTextColor(Color.rgb(147, 164, 184))
        setLineSpacing(0f, 1.18f)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun edit(hint: String, value: String) = EditText(this).apply {
        this.hint = hint
        setText(value)
        setTextColor(Color.WHITE)
        setHintTextColor(Color.rgb(108, 127, 148))
        setSingleLine(true)
        setPadding(dp(14), dp(12), dp(14), dp(12))
    }

    private fun card(vararg views: View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(12), dp(12), dp(12), dp(12))
        setBackgroundColor(Color.rgb(14, 27, 43))
        views.forEach { addView(it, LinearLayout.LayoutParams(-1, -2)) }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(22)
            bottomMargin = dp(18)
        }
    }

    private fun primaryButton(text: String, action: (() -> Unit)?) = Button(this).apply {
        this.text = text
        textSize = 15f
        setTextColor(Color.rgb(7, 17, 31))
        setTypeface(typeface, Typeface.BOLD)
        setBackgroundColor(Color.rgb(49, 215, 232))
        isAllCaps = false
        gravity = Gravity.CENTER
        setOnClickListener { action?.invoke() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(56)).apply { bottomMargin = dp(12) }
    }

    private fun secondaryButton(text: String, action: () -> Unit) = primaryButton(text, action).apply {
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(23, 47, 67))
    }

    private fun dangerButton(text: String, action: () -> Unit) = primaryButton(text, action).apply {
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(119, 34, 50))
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
