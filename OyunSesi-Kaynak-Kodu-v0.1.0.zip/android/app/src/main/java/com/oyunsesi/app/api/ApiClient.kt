package com.oyunsesi.app.api

import org.json.JSONObject
import java.io.BufferedReader
import java.net.HttpURLConnection
import java.net.URL

data class JoinCredentials(
    val roomCode: String,
    val participantToken: String,
    val serverUrl: String,
    val participantId: String
)

class ApiException(message: String) : Exception(message)

class ApiClient(private val baseUrl: String) {
    fun createRoom(displayName: String, lowData: Boolean): JoinCredentials =
        post("/v1/rooms", JSONObject().apply {
            put("displayName", displayName)
            put("lowData", lowData)
        })

    fun joinRoom(code: String, displayName: String, lowData: Boolean): JoinCredentials =
        post("/v1/rooms/$code/join", JSONObject().apply {
            put("displayName", displayName)
            put("lowData", lowData)
        })

    private fun post(path: String, body: JSONObject): JoinCredentials {
        val normalized = baseUrl.trim().trimEnd('/')
        if (!normalized.startsWith("https://")) {
            throw ApiException("Sunucu adresi https:// ile başlamalı.")
        }
        val connection = (URL(normalized + path).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 10_000
            readTimeout = 12_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
        }
        connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
        val responseText = stream?.bufferedReader()?.use(BufferedReader::readText).orEmpty()
        val response = runCatching { JSONObject(responseText) }.getOrNull()
        if (connection.responseCode !in 200..299) {
            throw ApiException(response?.optString("message")?.takeIf { it.isNotBlank() }
                ?: "Sunucu hatası (${connection.responseCode})")
        }
        return JoinCredentials(
            roomCode = response?.getString("roomCode") ?: throw ApiException("Oda kodu alınamadı."),
            participantToken = response.getString("participantToken"),
            serverUrl = response.getString("serverUrl"),
            participantId = response.optString("participantId")
        )
    }
}
